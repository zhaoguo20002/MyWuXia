using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Restore purchases, resotred event will be fired for ectach restored purchase")]
	public class ISN_RestorePurchases : FsmStateAction {
		
				


		public FsmString[] restoredProducts;
		public FsmString   currentRestoredItem;

		[Tooltip("Event fired when Store Kit product restored")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent ItemRestoredEvent;


		private List<FsmString> restoredProductsCash =  new List<FsmString>();


		public override void Reset() {
			restoredProductsCash = new List<FsmString>();
		}


		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);

			#if UNITY_EDITOR
			Fsm.Event(successEvent);
			Finish();
			return;
			#endif
			
		}

		private void OnBillingInit() {

			IOSInAppPurchaseManager.OnTransactionComplete += OnTransactionComplete;
			IOSInAppPurchaseManager.OnRestoreComplete += HandleOnRestoreComplete;
			IOSInAppPurchaseManager.instance.restorePurchases();
		}





		void OnTransactionComplete (IOSStoreKitResult resp) {


			switch(resp.State) {
			case InAppPurchaseState.Purchased:
			case InAppPurchaseState.Restored:
				restoredProductsCash.Add(resp.ProductIdentifier);
				currentRestoredItem.Value = resp.ProductIdentifier;
				Fsm.Event(ItemRestoredEvent);
				break;
			case InAppPurchaseState.Deferred:
			case InAppPurchaseState.Failed:
				Fsm.Event(failEvent);
				break;
			}


		}

		void HandleOnRestoreComplete (IOSStoreKitRestoreResult res) {
			IOSInAppPurchaseManager.OnTransactionComplete -= OnTransactionComplete;
			IOSInAppPurchaseManager.OnRestoreComplete -= HandleOnRestoreComplete;
			
			
			restoredProducts = restoredProductsCash.ToArray ();
			Fsm.Event(successEvent);
			Finish();
		}

		
	
		
	}
}




