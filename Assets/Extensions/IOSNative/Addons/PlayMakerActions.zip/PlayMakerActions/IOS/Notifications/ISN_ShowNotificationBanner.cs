﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_ShowNotificationBanner : FsmStateAction {
					
		public FsmString title;
		public FsmString message;
				
		public override void OnEnter() {
			IOSNotificationController.instance.ShowGmaeKitNotification(title.Value, message.Value);
			Finish();
		}
	}
}
