﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - iAd")]
	public class ISN_ShowBanner : FsmStateAction {

		public FsmInt bannerId;

		public override void OnEnter() {
			iAdBanner banner =  iAdBannerController.instance.GetBanner(bannerId.Value);
			if(banner != null) {
				banner.Show();
			}
		}

	}
}
