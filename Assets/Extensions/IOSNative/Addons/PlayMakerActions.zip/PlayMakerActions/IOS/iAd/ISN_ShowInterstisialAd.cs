﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - iAd")]
	public class ISN_ShowInterstisialAd : FsmStateAction {

		[Tooltip("Event fired when Ad is started")]
		public FsmEvent adShowedEvent;

		[Tooltip("Event fired when Ad is closed")]
		public FsmEvent adClosedEvent;
		
		[Tooltip("Event fired when Ad is failed to load")]
		public FsmEvent adFailedEvent;
		
		public override void OnEnter() {

			iAdBannerController.Instance.ShowInterstitialAd();
			iAdBannerController.InterstitialAdDidFinishAction += InterstitialAdDidFinishAction;
			iAdBannerController.InterstitialAdDidLoadAction += InterstitialAdDidLoadAction;
			iAdBannerController.InterstitialDidFailWithErrorAction += InterstitialDidFailWithErrorAction;

		}

		void InterstitialAdDidLoadAction () {
			Fsm.Event(adShowedEvent);
		}


		void InterstitialAdDidFinishAction () {
			Fsm.Event(adClosedEvent);
			FinishAction();
		}


		void InterstitialDidFailWithErrorAction () {
			Fsm.Event(adFailedEvent);
			FinishAction();
		}

		private void FinishAction() {
			iAdBannerController.InterstitialAdDidFinishAction -= InterstitialAdDidFinishAction;
			iAdBannerController.InterstitialAdDidLoadAction -= InterstitialAdDidLoadAction;
			iAdBannerController.InterstitialDidFailWithErrorAction -= InterstitialDidFailWithErrorAction;
			Finish();
		}
	}
}
