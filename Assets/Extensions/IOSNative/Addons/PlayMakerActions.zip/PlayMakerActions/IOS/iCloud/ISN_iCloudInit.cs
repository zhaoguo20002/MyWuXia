using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - iCloud")]
	public class ISN_iCloudInit : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public override void OnEnter() {

			bool IsInEdditorMode = false;

			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif

			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			iCloudManager.OnCloundInitAction += HandleOnCloundInitAction;
			iCloudManager.instance.init ();
		}

		void HandleOnCloundInitAction (ISN_Result res) {
			iCloudManager.OnCloundInitAction -= HandleOnCloundInitAction;


			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish();
		}


		void OnDestroy() {
			iCloudManager.OnCloundInitAction -= HandleOnCloundInitAction;
		}

	}
}

